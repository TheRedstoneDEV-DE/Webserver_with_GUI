# Webserver_with_GUI
An easy to use Webserver with GUI

This is a web server, written in java,
which has an easy to use GUI.
The webserver whithout GUI and config files is by SSaurel,
from his tutorial, but I have modifyed 
this code much.

The Java version, which is compiled,
is the version 14, but you can compile
the sourcecode yourself.

# Sourcecompiling and running
1. Download all files into the folder "src" and move it into one folder.

2. run:
>javac Webserver.java ServerMain.java

3. Now you can open your commandline and run:
>jar cfm FILENAME.jar manifest.txt *.class
 
 4. You can now execute it with: 
>java -jar FILENAME.jar
